﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Media;

namespace HastaneOtomasyon
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }


        private void lnklblRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //ÜYE OL SAYFASINA GİDİŞ

            UyeOl nuser = new UyeOl();
            this.Hide();
            nuser.Show();
        }

        private void Giris_Load(object sender, EventArgs e)
        {
            

            //FORM AÇILDIĞINDA ŞİFRE GİZLİ BİÇİMDE YAZILSIN

            txtPassword.PasswordChar = '*';
            
            //LOGİN'DE REMEMBER İÇİN

            txtTC.Text = Properties.Settings.Default["TC"].ToString();
            txtPassword.Text = Properties.Settings.Default["Sifre"].ToString();
            if (txtTC.Text.Count()>1)
            {
                chckRemember.Checked = true;
            }
        }

        private void chckPassword_CheckedChanged(object sender, EventArgs e)
        {
            //ŞİFREYİ GÖSTER/GİZLE 

            if (chckPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            if (txtTC.Text!="" && txtPassword.Text!="")
            {
                //TC bilgisi çekme
                AktarmaClass.tc = txtTC.Text;

                //BENİ HATIRLA 

                if (chckRemember.Checked)
                {
                    Properties.Settings.Default["TC"] = txtTC.Text;
                    Properties.Settings.Default["Sifre"] = txtPassword.Text;
                }
                else
                {
                    Properties.Settings.Default["TC"] = "";
                    Properties.Settings.Default["Sifre"] = "";
                }
                Properties.Settings.Default.Save();

                //LOGİN OLMA

                string login_tc = txtTC.Text;
                string login_sifre = txtPassword.Text;

                SqlConnection con = new SqlConnection("server=BERKANTSD; Initial Catalog=Hastane;Integrated Security=SSPI");
                SqlCommand cmd = new SqlCommand();
                con.Open();
                cmd.Connection = con;
                cmd.CommandText = "SELECT * FROM Login where login_tc='" + txtTC.Text + "' AND login_sifre='" + txtPassword.Text + "'";
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Anasayfa anasyf = new Anasayfa();
                    this.Hide();
                    anasyf.Show();
                }
                else
                {
                    MessageBox.Show("TC kimlik numarınızı ve şifrenizi kontrol ediniz.");
                }
                    con.Close();
            }
            else
            {
                MessageBox.Show("Lütfen TC ve Şifrenizi giriniz.");
            }
            System.Threading.Thread.Sleep(1000);

            SoundPlayer player = new SoundPlayer();

            string path = "C:\\Users\\berka\\source\\repos\\HastaneOtomasyon\\HastaneOtomasyon\\Sounds\\start.wav"; 

            player.SoundLocation = path;

            player.Play();
        }

        private void pbUser_Click(object sender, EventArgs e)
        {
            //BENİ HATIRLA BİLGİLENDİRME

            if (chckRemember.Checked)
            {
                MessageBox.Show("Kullaınıcı Adınızı ve Şifrenizi\n Beni Hatırla Olarak Kaydettiniz.", "Mesaj", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void txtTC_KeyPress(object sender, KeyPressEventArgs e)
        {
            //İstenilmeyen değer girilmesini engelleme ve karakter sınırlama

            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);

            if (txtTC.TextLength == 11)
            {
                e.Handled = true;
            }
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Karakter sınırlama

            if (txtPassword.TextLength == 12)
            {
                e.Handled = true;
            }
        }

        private void txtPassword_MouseHover(object sender, EventArgs e)
        {
            // Şifre girerken bilgilendirme 

            ToolTip Aciklama = new ToolTip();
            Aciklama.ToolTipTitle = "Bilgilendirme";
            Aciklama.ToolTipIcon = ToolTipIcon.Info;
            Aciklama.IsBalloon = true;

            Aciklama.SetToolTip(txtPassword, "Şifreniz en fazla 12 karakter olabilir ve özel karakterler(*,?) içermemelidir.");
        }

        private void Giris_FormClosing(object sender, FormClosingEventArgs e)
        {
        }

        private void btnLogin_MouseHover(object sender, EventArgs e)
        {
            btnLogin.Width = 140;
            btnLogin.Location = new Point(101,321);
            btnLogin.FlatAppearance.BorderColor = System.Drawing.ColorTranslator.FromHtml("#2d3436");
        }

        private void btnLogin_MouseLeave(object sender, EventArgs e)
        {
            btnLogin.FlatAppearance.BorderColor = Color.Black;
            btnLogin.Width = 130;
            btnLogin.Location = new Point(105,321);
        }

        private void txtTC_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTC_MouseHover(object sender, EventArgs e)
        {

        }

        private void txtTC_MouseLeave(object sender, EventArgs e)
        {
            txtTC.Width = 211;
            txtPassword.Width =211;
            txtTC.Location = new Point(59,236);
            txtPassword.Location = new Point(59,268);
            
        }

        private void txtTC_Click(object sender, EventArgs e)
        {
            txtTC.Width = 220;
            txtPassword.Width = 220;
            txtTC.Location = new Point(57,236);
            txtPassword.Location = new Point(57,268);
        }
    }
}
