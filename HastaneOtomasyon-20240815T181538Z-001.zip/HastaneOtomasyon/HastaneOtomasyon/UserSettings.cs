﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HastaneOtomasyon
{
    public partial class UserSettings : Form
    {
        public UserSettings()
        {
            InitializeComponent();
        }
        int sayac;
        //SQL BAĞLANTISI
        SqlConnection con = new SqlConnection("Server=BERKANTSD;Database=Hastane;Trusted_Connection=True;");

        private void kimlikBilgilerimToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void iletişimBilgilerimToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void UserSettings_Load(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select hasta_tc,hasta_ad,hasta_soyad,hasta_cinsiyet,hasta_dgmtar,hasta_dgmyer,hasta_babaad,hasta_annead,hasta_sifre from hasta where hasta_tc='" + AktarmaClass.tc + "'", con);
            sda.Fill(dt);
            dtgUserSettings.DataSource = dt;
            con.Close();
            dtgUserSettings.Columns[0].HeaderText = "TC";
            dtgUserSettings.Columns[1].HeaderText = "Ad";
            dtgUserSettings.Columns[2].HeaderText = "Soyad";
            dtgUserSettings.Columns[3].HeaderText = "Cinsiyet";
            dtgUserSettings.Columns[4].HeaderText = "Doğum Tarihi";
            dtgUserSettings.Columns[5].HeaderText = "Doğum Yeri";
            dtgUserSettings.Columns[6].HeaderText = "Baba Ad";
            dtgUserSettings.Columns[7].HeaderText = "Anne Ad";
            dtgUserSettings.Columns[8].HeaderText = "Şifre";
            dtgUserSettings.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Calibri", 9, FontStyle.Bold);
        }

        private void hesapBilgilerimToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select hasta_tc,hasta_ad,hasta_soyad,hasta_cinsiyet,hasta_dgmtar,hasta_dgmyer,hasta_babaad,hasta_annead,hasta_sifre from hasta where hasta_tc='"+AktarmaClass.tc+"'",con);
            sda.Fill(dt);
            dtgUserSettings.DataSource = dt;
            sayac = 1;

            dtgUserSettings.Rows[0].Cells[0].ReadOnly = true;
            dtgUserSettings.RowHeadersVisible = false;

            dtgUserSettings.Columns[0].HeaderText = "TC";
            dtgUserSettings.Columns[1].HeaderText = "Ad";
            dtgUserSettings.Columns[2].HeaderText = "Soyad";
            dtgUserSettings.Columns[3].HeaderText = "Cinsiyet";
            dtgUserSettings.Columns[4].HeaderText = "Doğum Tarihi";
            dtgUserSettings.Columns[5].HeaderText = "Doğum Yeri";
            dtgUserSettings.Columns[6].HeaderText = "Baba Adı";
            dtgUserSettings.Columns[7].HeaderText = "Anne Adı";
            dtgUserSettings.Columns[8].HeaderText = "Hesap Şifresi";
        }

        private void iletişimBilgilerimToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select hasta_tc,hasta_ceptel,hasta_evtel,hasta_eposta from hasta_iletisim where hasta_tc='"+AktarmaClass.tc+"'",con);
            sda.Fill(dt);
            dtgUserSettings.DataSource = dt;
            sayac = 2;

            dtgUserSettings.Rows[0].Cells[0].ReadOnly = true;
            dtgUserSettings.RowHeadersVisible = false;

            dtgUserSettings.Columns[0].HeaderText = "TC";
            dtgUserSettings.Columns[1].HeaderText = "Cep Telefonu";
            dtgUserSettings.Columns[2].HeaderText = "Ev Telefonu";
            dtgUserSettings.Columns[3].HeaderText = "E-Posta";
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //Seçili satırın X koordinatı

            int x = dtgUserSettings.CurrentCellAddress.Y;

            if (sayac == 1)
            {
                con.Close();
                con.Open();
                string hesap = "update hasta set hasta_tc=@hasta_tc, hasta_ad=@hasta_ad, hasta_soyad=@hasta_soyad, hasta_cinsiyet=@hasta_cinsiyet, hasta_dgmtar=@hasta_dgmtar, hasta_dgmyer=@hasta_dgmyer, hasta_babaad=@hasta_babaad, hasta_annead=@hasta_annead, hasta_sifre=@hasta_sifre where hasta_tc=@hasta_tc";

                SqlCommand komut = new SqlCommand(hesap, con);
                komut.Parameters.AddWithValue("@hasta_tc", dtgUserSettings.Rows[x].Cells[0].Value);
                komut.Parameters.AddWithValue("@hasta_ad", dtgUserSettings.Rows[x].Cells[1].Value.ToString());
                komut.Parameters.AddWithValue("@hasta_soyad", dtgUserSettings.Rows[x].Cells[2].Value.ToString());
                komut.Parameters.AddWithValue("@hasta_cinsiyet", dtgUserSettings.Rows[x].Cells[3].Value.ToString());
                komut.Parameters.AddWithValue("@hasta_dgmtar", dtgUserSettings.Rows[x].Cells[4].Value);
                komut.Parameters.AddWithValue("@hasta_dgmyer", dtgUserSettings.Rows[x].Cells[5].Value.ToString());
                komut.Parameters.AddWithValue("@hasta_babaad", dtgUserSettings.Rows[x].Cells[6].Value.ToString());
                komut.Parameters.AddWithValue("@hasta_annead", dtgUserSettings.Rows[x].Cells[7].Value.ToString());
                komut.Parameters.AddWithValue("@hasta_sifre", dtgUserSettings.Rows[x].Cells[8].Value);

                komut.ExecuteNonQuery();

                string login1 = "update Login set login_tc=@login_tc, login_sifre=@login_sifre where login_tc=@login_tc";

                SqlCommand cmd = new SqlCommand(login1, con);

                cmd.Parameters.AddWithValue("@login_tc", dtgUserSettings.Rows[x].Cells[0].Value);
                cmd.Parameters.AddWithValue("@login_sifre", dtgUserSettings.Rows[x].Cells[8].Value.ToString());

                cmd.ExecuteNonQuery();
                MessageBox.Show("Hesap Bilgileriniz Güncellendi.");
                con.Close();
            }
            else if (sayac == 2)
            {
                con.Close();
                con.Open();

                string iletisim = "update hasta_iletisim set hasta_tc=@hasta_tc, hasta_ceptel=@hasta_ceptel, hasta_evtel=@hasta_evtel, hasta_eposta=@hasta_eposta where hasta_tc=@hasta_tc";

                SqlCommand komut = new SqlCommand(iletisim, con);
                komut.Parameters.AddWithValue("@hasta_tc", dtgUserSettings.Rows[x].Cells[0].Value);
                komut.Parameters.AddWithValue("@hasta_ceptel", dtgUserSettings.Rows[x].Cells[1].Value);
                komut.Parameters.AddWithValue("@hasta_evtel", dtgUserSettings.Rows[x].Cells[2].Value);
                komut.Parameters.AddWithValue("@hasta_eposta", dtgUserSettings.Rows[x].Cells[3].Value.ToString());

                komut.ExecuteNonQuery();
                MessageBox.Show("İletişim Bilgileriniz Güncellendi.");
            }
            else
            {
                MessageBox.Show("Lütfen işlem yapacağınız menüye tıklayın.");
            }
        }
        private void PreviousToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Anasayfa anasyf = new Anasayfa();
            this.Hide();
            anasyf.Show();
        }

        private void dtgUserSettings_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
        }
    }
}
