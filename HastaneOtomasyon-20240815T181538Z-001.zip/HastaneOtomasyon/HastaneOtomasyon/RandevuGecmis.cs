﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HastaneOtomasyon
{
    public partial class RandevuGecmis : Form
    {
        public RandevuGecmis()
        {
            InitializeComponent();
        }
        //SQL bağlantı için

        SqlConnection con = new SqlConnection("Server=BERKANTSD;Database=Hastane;Trusted_Connection=True;");

        private void RandevuGecmis_Load(object sender, EventArgs e)
        {
            // Kişinin randevu bilgilerini getirme

            con.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("Select hasta_tc,hekim_ad,hastane_ad,klinik_ad,myeri_ad,randevu_tarih,randevu_saat from Randevu where hasta_tc='"+AktarmaClass.tc+"'",con);
            sda.Fill(dt);
            dtgRandevuGecmis.DataSource = dt;
            con.Close();
            dtgRandevuGecmis.ReadOnly = true;
            dtgRandevuGecmis.RowHeadersVisible = false;

            // Sütun adlarını düzenleme

            dtgRandevuGecmis.Columns[0].HeaderText = "TC";
            dtgRandevuGecmis.Columns[1].HeaderText = "Hekim";
            dtgRandevuGecmis.Columns[2].HeaderText = "Hastane";
            dtgRandevuGecmis.Columns[3].HeaderText = "Klinik";
            dtgRandevuGecmis.Columns[4].HeaderText = "Muayene Yeri";
            dtgRandevuGecmis.Columns[5].HeaderText = "Randevu Tarihi";
            dtgRandevuGecmis.Columns[6].HeaderText = "Randevu Saati";
            dtgRandevuGecmis.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Calibri", 9, FontStyle.Bold);
        }

        private void dtgRandevuGecmis_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            Anasayfa anasayf = new Anasayfa();
            this.Hide();
            anasayf.Show();
        }

        private void previousToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Anasayfa ansyf = new Anasayfa();
            this.Hide();
            ansyf.Show();
        }

        private void randevuyuSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void randevuyuSilToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            //Randevuyu silme ve dtg'yi güncelleme

            con.Close();
            con.Open();

            int x = dtgRandevuGecmis.CurrentCellAddress.X;

            string del = "delete from Randevu where hasta_tc=@hasta_tc and hekim_ad=@hekim_ad and hastane_ad=@hastane_ad and klinik_ad=@klinik_ad and myeri_ad=@myeri_ad and randevu_tarih=@randevu_tarih and randevu_saat=@randevu_saat";

            SqlCommand cmd = new SqlCommand(del,con);

            cmd.Parameters.AddWithValue("@hasta_tc",dtgRandevuGecmis.Rows[x].Cells[0].Value);
            cmd.Parameters.AddWithValue("@hekim_ad", dtgRandevuGecmis.Rows[x].Cells[1].Value.ToString());
            cmd.Parameters.AddWithValue("@hastane_ad", dtgRandevuGecmis.Rows[x].Cells[2].Value.ToString());
            cmd.Parameters.AddWithValue("@klinik_ad", dtgRandevuGecmis.Rows[x].Cells[3].Value.ToString());
            cmd.Parameters.AddWithValue("@myeri_ad", dtgRandevuGecmis.Rows[x].Cells[4].Value.ToString());
            cmd.Parameters.AddWithValue("@randevu_tarih", dtgRandevuGecmis.Rows[x].Cells[5].Value);
            cmd.Parameters.AddWithValue("@randevu_saat", dtgRandevuGecmis.Rows[x].Cells[6].Value);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Randevunuz Silinmiştir.");

            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select hasta_tc,hekim_ad,hastane_ad,klinik_ad,myeri_ad,randevu_tarih,randevu_saat from Randevu where hasta_tc='" + AktarmaClass.tc + "'", con);
            sda.Fill(dt);
            dtgRandevuGecmis.DataSource = dt;
            con.Close();
        }
    }
}
