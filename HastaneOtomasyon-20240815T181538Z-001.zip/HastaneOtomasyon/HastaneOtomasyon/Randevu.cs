﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace HastaneOtomasyon
{
    public partial class Randevu : Form
    {
        public Randevu()
        {
            InitializeComponent();
        }

        //SQL Bağlantısı

        SqlConnection con = new SqlConnection("Server=BERKANTSD;Database=Hastane;Trusted_Connection=True;");

        private void Randevu_Load(object sender, EventArgs e)
        {
            //Birinci combobox'a şehirleri getirmek için
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select*from il",con);
            sda.Fill(dt);
            cbCity.ValueMember = "il_id";
            cbCity.DisplayMember = "il_ad";
            cbCity.DataSource = dt;

            //Datetimepicker kısıtlama
            dtpAppointment.MinDate = DateTime.Today;
            dtpAppointment.MaxDate = DateTime.Today.AddDays(7);
            dtgPhysician.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Calibri", 9, FontStyle.Bold);
            dtgAppointment.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Calibri", 9, FontStyle.Bold);
        }
        private void cbDistrictPolyclinic_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Muayene yerlerini getirme

            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select*from spoliklinigi_myeri where spoliklinigi_id='"+cbDistrictPolyclinic.SelectedValue+"'",con);
            sda.Fill(dt);
            cbInspectionPlace.ValueMember = "myeri_id";
            cbInspectionPlace.DisplayMember = "myeri_ad";
            cbInspectionPlace.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Seçimleri temizleme

            cbCity.Text = "";
            cbDistrict.Text = "";
            cbClinic.Text = "";
            cbHospital.Text = "";
            cbDistrictPolyclinic.Text = "";
            cbInspectionPlace.Text = "";
            cbPhysician.Text = "";
        }

        private void cbCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            // İlçeleri getirme

            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select*from il_ilce where il_id='"+cbCity.SelectedValue+"'",con);
            sda.Fill(dt);
            cbDistrict.ValueMember = "ilce_id";
            cbDistrict.DisplayMember = "ilce_ad";
            cbDistrict.DataSource = dt;
        }

        private void cbDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Klinikleri getirme

            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select*from ilce_klinik where ilce_id='"+cbDistrict.SelectedValue+"'",con);
            sda.Fill(dt);
            cbClinic.ValueMember = "klinik_id";
            cbClinic.DisplayMember = "klinik_ad";
            cbClinic.DataSource = dt;
        }

        private void cbClinic_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Hastaneleri getirme

            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select*from klinik_hastane where il_id='" + cbCity.SelectedValue + "' and ilce_id='" + cbDistrict.SelectedValue + "' and klinik_id='" + cbClinic.SelectedValue + "'", con);
            sda.Fill(dt);
            cbHospital.ValueMember = "hastane_id";
            cbHospital.DisplayMember = "hastane_ad";
            cbHospital.DataSource = dt;
        }

        private void cbHospital_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Semt polikliniklerini getirme

            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select*from hastane_spoliklinigi where hastane_id='"+cbHospital.SelectedValue+"'",con);
            sda.Fill(dt);
            cbDistrictPolyclinic.ValueMember = "spoliklinigi_id";
            cbDistrictPolyclinic.DisplayMember = "spoliklinigi_ad";
            cbDistrictPolyclinic.DataSource = dt;
        }

        private void cbInspectionPlace_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Hekimleri getirme

            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select*from myeri_hekim where hastane_id='"+cbHospital.SelectedValue+"' and klinik_id='"+cbClinic.SelectedValue+"' and myeri_id='"+cbInspectionPlace.SelectedValue+"'", con);
            sda.Fill(dt);
            cbPhysician.ValueMember = "hekim_id";
            cbPhysician.DisplayMember = "hekim_ad";
            cbPhysician.DataSource = dt;
        }

        private void btnRandevuAra_Click(object sender, EventArgs e)
        {
            //Randevu arama yapma ve dtg'ye aktarma

            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select '"+cbPhysician.Text+"','"+cbHospital.Text+"','"+cbClinic.Text+"','"+cbInspectionPlace.Text+"' from hekim inner join myeri on myeri_id=hekim_id inner join hastane on myeri_id=hastane_id inner join klinik on hastane_id=klinik_id ", con);
            sda.Fill(dt);
            dtgPhysician.DataSource = dt;

            // Sütun adlarını düzenleme

            dtgPhysician.Columns[0].HeaderText = "Hekim";
            dtgPhysician.Columns[1].HeaderText = "Hastane";
            dtgPhysician.Columns[2].HeaderText = "Klinik";
            dtgPhysician.Columns[3].HeaderText = "Muayene Yeri";
            dtgPhysician.RowHeadersVisible = false;
        }

        private void dtgPhysician_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Hekimlerin randevu saatlerini getirme

            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter("select hekim_rsaat from hekim_rndv",con);
            sda.Fill(dt);
            dtgAppointment.DataSource = dt;
            dtgAppointment.Columns[0].HeaderText = "Randevu Saatleri";
            dtgAppointment.RowHeadersVisible = false;
        }

        private void dtgAppointment_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Seçili satırın X koordinatı

            int xkoordinat = dtgAppointment.CurrentCellAddress.X;

            //Seçili satırın Y koordinatı

            int ykoordinat = dtgAppointment.CurrentCellAddress.Y;

            string str = "";

            str = dtgAppointment.Rows[ykoordinat].Cells[xkoordinat].Value.ToString();

            //Randevuyu Kaydetme
            con.Open();
            string kayit = "insert into Randevu(hasta_tc,hekim_ad,hastane_ad,klinik_ad,myeri_ad,randevu_tarih,randevu_saat) values(@hasta_tc,@hekim_ad,@hastane_ad,@klinik_ad,@myeri_ad,@randevu_tarih,@randevu_saat)";
            SqlCommand cmd = new SqlCommand(kayit, con);
            cmd.Parameters.AddWithValue("@hasta_tc", AktarmaClass.tc);
            cmd.Parameters.AddWithValue("@hekim_ad",cbPhysician.Text);
            cmd.Parameters.AddWithValue("@hastane_ad", cbHospital.Text);
            cmd.Parameters.AddWithValue("@klinik_ad", cbClinic.Text);
            cmd.Parameters.AddWithValue("@myeri_ad", cbInspectionPlace.Text);
            cmd.Parameters.AddWithValue("@randevu_tarih", dtpAppointment.Value);
            cmd.Parameters.AddWithValue("@randevu_saat",str);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Randevunuz Başarıyla Kayıt Edilmiştir.");
            con.Close();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
        }

        private void dtgPhysician_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void previousToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //

            Anasayfa af = new Anasayfa();
            this.Hide();
            af.Show();
        }

        private void btnRandevuAra_MouseHover(object sender, EventArgs e)
        {
        }

        private void previousToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
        }

        private void previousToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
        }

        private void cbPhysician_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
