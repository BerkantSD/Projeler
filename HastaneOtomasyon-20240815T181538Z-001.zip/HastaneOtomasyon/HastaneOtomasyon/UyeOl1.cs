﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HastaneOtomasyon
{
    public partial class UyeOl1 : Form
    {
        public UyeOl1()
        {
            InitializeComponent();
        }
        //SQL Connection Tanımı

        static string conString = "Server=BERKANTSD;Database=Hastane;Trusted_Connection=True;";

        //SQL bağlantısı oluşturma

        SqlConnection con = new SqlConnection(conString);

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Bilgileri Kaydetme Kısmı

            try
            {
                if (txtEposta.Text!="" && txtPhone.Text!="" || txtHomePhone.Text!="")
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();

                        string kayit = "insert into hasta_iletisim(hasta_tc,hasta_ceptel,hasta_evtel,hasta_eposta) values (@hasta_tc,@hasta_ceptel,@hasta_evtel,@hasta_eposta)";

                        SqlCommand komut = new SqlCommand(kayit, con);

                        komut.Parameters.AddWithValue("@hasta_tc", UyeTcAktar.tc);
                        komut.Parameters.AddWithValue("@hasta_ceptel", txtPhone.Text);
                        komut.Parameters.AddWithValue("@hasta_evtel", txtHomePhone.Text);
                        komut.Parameters.AddWithValue("@hasta_eposta", txtEposta.Text);

                        komut.ExecuteNonQuery();

                        //Parola sayfasına geçiş

                        MessageBox.Show("Kayıt İşlemi Başarıyla Gerçekleştirildi. Giriş Sayfasına Yönlendirileceksiniz.");
                        Giris grs = new Giris();
                        this.Hide();
                        grs.Show();

                        con.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Gerekli Bilgileri Doldurunuz.");
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show("İşlem Sırasında Hata Oluştu." + hata.Message);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //Hasta tablosundaki bilgileri silme

            con.Close();
            con.Open();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("delete from hasta where hasta_tc='"+uyegonder.uye_tc+"'", con);
            cmd.ExecuteNonQuery();
            con.Close();
        

            //uyeol sayfasına yönlendirme

            UyeOl nuser = new UyeOl();
            this.Hide();
            nuser.Show();
        }

        private void UyeOl1_Load(object sender, EventArgs e)
        { 
        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            //İstenilmeyen değer girilmesini engelleme ve karakter sınırlama

            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);

            if (txtPhone.TextLength == 10)
            {
                e.Handled = true;
            }
        }

        private void txtHomePhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            //İstenilmeyen değer girilmesini engelleme ve karakter sınırlama

            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);

            if (txtHomePhone.TextLength == 10)
            {
                e.Handled = true;
            }
        }

        private void txtEposta_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Karakter sınırlama

            if (txtEposta.TextLength == 50)
            {
                e.Handled = true;
            }
        }

        private void txtPhone_MouseHover(object sender, EventArgs e)
        {
            // Cep Telefon girişi için bilgiledirme

            ToolTip Aciklama = new ToolTip();
            Aciklama.ToolTipTitle = "Bilgilendirme";
            Aciklama.ToolTipIcon = ToolTipIcon.Info;
            Aciklama.IsBalloon = true;

            Aciklama.SetToolTip(txtPhone, "Telefon Numaranızı 538XXXXXXXX şeklinde giriniz.");
        }

        private void txtHomePhone_MouseHover(object sender, EventArgs e)
        {
            // Ev telefonu girişi için bilgilendirme

            ToolTip Aciklama = new ToolTip();
            Aciklama.ToolTipTitle = "Bilgilendirme";
            Aciklama.ToolTipIcon = ToolTipIcon.Info;
            Aciklama.IsBalloon = true;

            Aciklama.SetToolTip(txtHomePhone, "Ev Telefonunuzu 216XXXXXXX şeklinde giriniz.");
        }
    }
}
