﻿namespace HastaneOtomasyon
{
    partial class Randevu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cbCity = new System.Windows.Forms.ComboBox();
            this.cbDistrict = new System.Windows.Forms.ComboBox();
            this.cbClinic = new System.Windows.Forms.ComboBox();
            this.cbInspectionPlace = new System.Windows.Forms.ComboBox();
            this.cbDistrictPolyclinic = new System.Windows.Forms.ComboBox();
            this.cbHospital = new System.Windows.Forms.ComboBox();
            this.cbPhysician = new System.Windows.Forms.ComboBox();
            this.dtgPhysician = new System.Windows.Forms.DataGridView();
            this.dtgAppointment = new System.Windows.Forms.DataGridView();
            this.btnRandevuAra = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.dtpAppointment = new System.Windows.Forms.DateTimePicker();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.previousToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dtgPhysician)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgAppointment)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbCity
            // 
            this.cbCity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbCity.FormattingEnabled = true;
            this.cbCity.Location = new System.Drawing.Point(12, 30);
            this.cbCity.Name = "cbCity";
            this.cbCity.Size = new System.Drawing.Size(290, 21);
            this.cbCity.TabIndex = 0;
            this.cbCity.SelectedIndexChanged += new System.EventHandler(this.cbCity_SelectedIndexChanged);
            // 
            // cbDistrict
            // 
            this.cbDistrict.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbDistrict.FormattingEnabled = true;
            this.cbDistrict.Location = new System.Drawing.Point(12, 57);
            this.cbDistrict.Name = "cbDistrict";
            this.cbDistrict.Size = new System.Drawing.Size(290, 21);
            this.cbDistrict.TabIndex = 1;
            this.cbDistrict.SelectedIndexChanged += new System.EventHandler(this.cbDistrict_SelectedIndexChanged);
            // 
            // cbClinic
            // 
            this.cbClinic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbClinic.FormattingEnabled = true;
            this.cbClinic.Location = new System.Drawing.Point(12, 84);
            this.cbClinic.Name = "cbClinic";
            this.cbClinic.Size = new System.Drawing.Size(290, 21);
            this.cbClinic.TabIndex = 2;
            this.cbClinic.SelectedIndexChanged += new System.EventHandler(this.cbClinic_SelectedIndexChanged);
            // 
            // cbInspectionPlace
            // 
            this.cbInspectionPlace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbInspectionPlace.FormattingEnabled = true;
            this.cbInspectionPlace.Location = new System.Drawing.Point(12, 165);
            this.cbInspectionPlace.Name = "cbInspectionPlace";
            this.cbInspectionPlace.Size = new System.Drawing.Size(290, 21);
            this.cbInspectionPlace.TabIndex = 5;
            this.cbInspectionPlace.SelectedIndexChanged += new System.EventHandler(this.cbInspectionPlace_SelectedIndexChanged);
            // 
            // cbDistrictPolyclinic
            // 
            this.cbDistrictPolyclinic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbDistrictPolyclinic.FormattingEnabled = true;
            this.cbDistrictPolyclinic.Location = new System.Drawing.Point(12, 138);
            this.cbDistrictPolyclinic.Name = "cbDistrictPolyclinic";
            this.cbDistrictPolyclinic.Size = new System.Drawing.Size(290, 21);
            this.cbDistrictPolyclinic.TabIndex = 4;
            this.cbDistrictPolyclinic.SelectedIndexChanged += new System.EventHandler(this.cbDistrictPolyclinic_SelectedIndexChanged);
            // 
            // cbHospital
            // 
            this.cbHospital.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbHospital.FormattingEnabled = true;
            this.cbHospital.Location = new System.Drawing.Point(12, 111);
            this.cbHospital.Name = "cbHospital";
            this.cbHospital.Size = new System.Drawing.Size(290, 21);
            this.cbHospital.TabIndex = 3;
            this.cbHospital.SelectedIndexChanged += new System.EventHandler(this.cbHospital_SelectedIndexChanged);
            // 
            // cbPhysician
            // 
            this.cbPhysician.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbPhysician.FormattingEnabled = true;
            this.cbPhysician.Location = new System.Drawing.Point(12, 192);
            this.cbPhysician.Name = "cbPhysician";
            this.cbPhysician.Size = new System.Drawing.Size(290, 21);
            this.cbPhysician.TabIndex = 6;
            this.cbPhysician.SelectedIndexChanged += new System.EventHandler(this.cbPhysician_SelectedIndexChanged);
            // 
            // dtgPhysician
            // 
            this.dtgPhysician.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgPhysician.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dtgPhysician.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgPhysician.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedHorizontal;
            this.dtgPhysician.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgPhysician.DefaultCellStyle = dataGridViewCellStyle1;
            this.dtgPhysician.Location = new System.Drawing.Point(0, 252);
            this.dtgPhysician.MultiSelect = false;
            this.dtgPhysician.Name = "dtgPhysician";
            this.dtgPhysician.ReadOnly = true;
            this.dtgPhysician.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgPhysician.Size = new System.Drawing.Size(801, 280);
            this.dtgPhysician.TabIndex = 7;
            this.dtgPhysician.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgPhysician_CellClick);
            this.dtgPhysician.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgPhysician_CellContentClick);
            // 
            // dtgAppointment
            // 
            this.dtgAppointment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgAppointment.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dtgAppointment.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgAppointment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgAppointment.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgAppointment.Location = new System.Drawing.Point(308, 57);
            this.dtgAppointment.MultiSelect = false;
            this.dtgAppointment.Name = "dtgAppointment";
            this.dtgAppointment.ReadOnly = true;
            this.dtgAppointment.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgAppointment.Size = new System.Drawing.Size(492, 189);
            this.dtgAppointment.TabIndex = 8;
            this.dtgAppointment.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgAppointment_CellClick);
            // 
            // btnRandevuAra
            // 
            this.btnRandevuAra.BackColor = System.Drawing.Color.Transparent;
            this.btnRandevuAra.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnRandevuAra.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRandevuAra.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRandevuAra.ForeColor = System.Drawing.SystemColors.Control;
            this.btnRandevuAra.Location = new System.Drawing.Point(12, 219);
            this.btnRandevuAra.Name = "btnRandevuAra";
            this.btnRandevuAra.Size = new System.Drawing.Size(144, 27);
            this.btnRandevuAra.TabIndex = 9;
            this.btnRandevuAra.Text = "Randevu Ara";
            this.btnRandevuAra.UseVisualStyleBackColor = false;
            this.btnRandevuAra.Click += new System.EventHandler(this.btnRandevuAra_Click);
            this.btnRandevuAra.MouseHover += new System.EventHandler(this.btnRandevuAra_MouseHover);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Transparent;
            this.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnClear.FlatAppearance.BorderSize = 0;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClear.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnClear.ForeColor = System.Drawing.SystemColors.Control;
            this.btnClear.Location = new System.Drawing.Point(162, 219);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(140, 27);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Temizle";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // dtpAppointment
            // 
            this.dtpAppointment.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.dtpAppointment.CalendarTitleBackColor = System.Drawing.SystemColors.InactiveCaption;
            this.dtpAppointment.CustomFormat = "yyyy-MM-dd";
            this.dtpAppointment.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpAppointment.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAppointment.Location = new System.Drawing.Point(308, 31);
            this.dtpAppointment.Name = "dtpAppointment";
            this.dtpAppointment.Size = new System.Drawing.Size(492, 20);
            this.dtpAppointment.TabIndex = 11;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.previousToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // previousToolStripMenuItem
            // 
            this.previousToolStripMenuItem.Image = global::HastaneOtomasyon.Properties.Resources.left_arrow;
            this.previousToolStripMenuItem.Name = "previousToolStripMenuItem";
            this.previousToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0);
            this.previousToolStripMenuItem.Size = new System.Drawing.Size(20, 24);
            this.previousToolStripMenuItem.Click += new System.EventHandler(this.previousToolStripMenuItem_Click);
            this.previousToolStripMenuItem.MouseLeave += new System.EventHandler(this.previousToolStripMenuItem_MouseLeave);
            this.previousToolStripMenuItem.MouseHover += new System.EventHandler(this.previousToolStripMenuItem_MouseHover);
            // 
            // Randevu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::HastaneOtomasyon.Properties.Resources.RandevuWallpaper;
            this.ClientSize = new System.Drawing.Size(800, 529);
            this.ControlBox = false;
            this.Controls.Add(this.dtpAppointment);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnRandevuAra);
            this.Controls.Add(this.dtgAppointment);
            this.Controls.Add(this.dtgPhysician);
            this.Controls.Add(this.cbPhysician);
            this.Controls.Add(this.cbInspectionPlace);
            this.Controls.Add(this.cbDistrictPolyclinic);
            this.Controls.Add(this.cbHospital);
            this.Controls.Add(this.cbClinic);
            this.Controls.Add(this.cbDistrict);
            this.Controls.Add(this.cbCity);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Randevu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Randevu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgPhysician)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgAppointment)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbCity;
        private System.Windows.Forms.ComboBox cbDistrict;
        private System.Windows.Forms.ComboBox cbClinic;
        private System.Windows.Forms.ComboBox cbInspectionPlace;
        private System.Windows.Forms.ComboBox cbDistrictPolyclinic;
        private System.Windows.Forms.ComboBox cbHospital;
        private System.Windows.Forms.ComboBox cbPhysician;
        private System.Windows.Forms.DataGridView dtgPhysician;
        private System.Windows.Forms.DataGridView dtgAppointment;
        private System.Windows.Forms.Button btnRandevuAra;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.DateTimePicker dtpAppointment;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem previousToolStripMenuItem;
    }
}