﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace HastaneOtomasyon
{
    public partial class Anasayfa : Form
    {
        public Anasayfa()
        {
            InitializeComponent();
        }

        private void btnRandevu_Click(object sender, EventArgs e)
        {
            Randevu rndv = new Randevu();
            this.Hide();
            rndv.Show();
        }

        private void btnRandevuGecmis_Click(object sender, EventArgs e)
        {
            RandevuGecmis rndvgcms = new RandevuGecmis();
            this.Hide();
            rndvgcms.Show();
        }

        private void btnUserSettings_Click(object sender, EventArgs e)
        {
            UserSettings us = new UserSettings();
            this.Hide();
            us.Show();
        }

        private void btnDuyuru_Click(object sender, EventArgs e)
        {
            Duyurular dyr = new Duyurular();
            this.Hide();
            dyr.Show();
        }

        private void Anasayfa_Load(object sender, EventArgs e)
        {

        }

        private void btnDestek_Click(object sender, EventArgs e)
        {
            Destek dstk = new Destek();
            this.Hide();
            dstk.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Takılmaması için 1 saniye bekletme ve hoş geldiniz mesajı

            System.Threading.Thread.Sleep(1000);

            SoundPlayer player = new SoundPlayer();

            string path = "C:\\Users\\berka\\source\\repos\\HastaneOtomasyon\\HastaneOtomasyon\\Sounds\\exit.wav";

            player.SoundLocation = path;

            player.Play();

            // Giriş sayfasına yönlendirme

            Giris grs = new Giris();
            this.Hide();
            grs.Show();
        }
    }
}
