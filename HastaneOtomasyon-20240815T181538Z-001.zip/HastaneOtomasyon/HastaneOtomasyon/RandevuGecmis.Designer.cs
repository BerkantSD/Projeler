﻿namespace HastaneOtomasyon
{
    partial class RandevuGecmis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgRandevuGecmis = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.previousToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randevuyuSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dtgRandevuGecmis)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtgRandevuGecmis
            // 
            this.dtgRandevuGecmis.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgRandevuGecmis.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dtgRandevuGecmis.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgRandevuGecmis.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedHorizontal;
            this.dtgRandevuGecmis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgRandevuGecmis.Location = new System.Drawing.Point(0, 27);
            this.dtgRandevuGecmis.Name = "dtgRandevuGecmis";
            this.dtgRandevuGecmis.Size = new System.Drawing.Size(801, 450);
            this.dtgRandevuGecmis.TabIndex = 0;
            this.dtgRandevuGecmis.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgRandevuGecmis_CellContentClick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.previousToolStripMenuItem,
            this.randevuyuSilToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // previousToolStripMenuItem
            // 
            this.previousToolStripMenuItem.Image = global::HastaneOtomasyon.Properties.Resources.left_arrow;
            this.previousToolStripMenuItem.Name = "previousToolStripMenuItem";
            this.previousToolStripMenuItem.Size = new System.Drawing.Size(28, 24);
            this.previousToolStripMenuItem.Click += new System.EventHandler(this.previousToolStripMenuItem_Click);
            // 
            // randevuyuSilToolStripMenuItem
            // 
            this.randevuyuSilToolStripMenuItem.BackColor = System.Drawing.Color.Red;
            this.randevuyuSilToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control;
            this.randevuyuSilToolStripMenuItem.Name = "randevuyuSilToolStripMenuItem";
            this.randevuyuSilToolStripMenuItem.Size = new System.Drawing.Size(93, 24);
            this.randevuyuSilToolStripMenuItem.Text = "Randevuyu Sil";
            this.randevuyuSilToolStripMenuItem.Click += new System.EventHandler(this.randevuyuSilToolStripMenuItem_Click_1);
            // 
            // RandevuGecmis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HastaneOtomasyon.Properties.Resources.RandevuWallpaper;
            this.ClientSize = new System.Drawing.Size(800, 477);
            this.ControlBox = false;
            this.Controls.Add(this.dtgRandevuGecmis);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "RandevuGecmis";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.RandevuGecmis_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgRandevuGecmis)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgRandevuGecmis;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem previousToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randevuyuSilToolStripMenuItem;
    }
}