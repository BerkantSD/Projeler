﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HastaneOtomasyon
{
    public partial class UyeOl : Form
    {
        public UyeOl()
        {
            InitializeComponent();
        }
        //SQL Connection Tanımı

        static string conString = "Server=BERKANTSD;Database=Hastane;Trusted_Connection=True;";

        //SQL BAĞLANTISI OLUŞTURMA

        SqlConnection con = new SqlConnection(conString);

        //CİNSİYET İÇİN DEĞER OLUŞTURMA
    
        string cinsiyet = "";

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Cinsiyet seçiminin belirlenme kısmı

            if (rbErkek.Checked)
            {
                cinsiyet = "Erkek";
            }
            else if (rbKadın.Checked)
            {
                cinsiyet = "Kadın";
            }

            //KİMLİK BİLGİLERİNİ VE LOGİN BİLGİLERİNİ KAYDETME

            try
            {
                if (txtTC.Text == "" || txtName.Text=="" || txtSurname.Text=="" || cinsiyet=="" || txtPlcOfBirth.Text=="" || txtFthrName.Text=="" || txtMthrName.Text=="" || txtPassword.Text=="")
                {
                    MessageBox.Show("Lütfen Gerekli Alanları Doldurunuz.");
                }
                else
                { 


                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();

                        string kayit = "insert into hasta(hasta_tc,hasta_ad,hasta_soyad,hasta_cinsiyet,hasta_dgmtar,hasta_dgmyer,hasta_babaad,hasta_annead,hasta_sifre) values (@hasta_tc,@hasta_ad,@hasta_soyad,@hasta_cinsiyet,@hasta_dgmtar,@hasta_dgmyer,@hasta_babaad,@hasta_annead,@hasta_sifre)";

                        SqlCommand komut = new SqlCommand(kayit, con);

                        komut.Parameters.AddWithValue("@hasta_tc", txtTC.Text);
                        komut.Parameters.AddWithValue("@hasta_ad", txtName.Text);
                        komut.Parameters.AddWithValue("@hasta_soyad", txtSurname.Text);
                        komut.Parameters.AddWithValue("@hasta_cinsiyet", cinsiyet);
                        komut.Parameters.AddWithValue("@hasta_dgmtar", dtpDate.Value);
                        komut.Parameters.AddWithValue("@hasta_dgmyer", txtPlcOfBirth.Text);
                        komut.Parameters.AddWithValue("@hasta_babaad", txtFthrName.Text);
                        komut.Parameters.AddWithValue("@hasta_annead", txtMthrName.Text);
                        komut.Parameters.AddWithValue("@hasta_sifre",txtPassword.Text);

                        komut.ExecuteNonQuery();

                        con.Close();
                    }

                    if (con.State==ConnectionState.Closed)
                    {
                        con.Open();
                        string kayit = "insert into Login(login_tc,login_sifre) values (@login_tc,@login_sifre)";

                        SqlCommand komut = new SqlCommand(kayit, con);

                        komut.Parameters.AddWithValue("@login_tc", txtTC.Text);
                        komut.Parameters.AddWithValue("@login_sifre",txtPassword.Text);

                        komut.ExecuteNonQuery();


                        //ANASAYFAYA GEÇİŞ

                        UyeTcAktar.tc = txtTC.Text;
                        UyeOl1 nuser1 = new UyeOl1();
                        this.Hide();
                        nuser1.Show();

                        con.Close();
                    }

                }
                
            }
            catch (Exception hata)
            {
                MessageBox.Show("İşlem Sırasında Hata Oluştu." + hata.Message);
            }

            uyegonder.uye_tc = txtTC.Text;
        }

        private void UyeOl_Load(object sender, EventArgs e)
        {
            // Tarih seçimini kısıtlama

            dtpDate.MaxDate = DateTime.Today;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //Giriş sayfasına yönlendirme

            Giris grs = new Giris();
            this.Hide();
            grs.Show();
        }

        private void txtTC_KeyPress(object sender, KeyPressEventArgs e)
        {
            // İstenilmeyen değer girilmesini engelleme ve karakter sınırlama

            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);

            if (txtTC.TextLength == 11)
            {
                e.Handled = true;
            }
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //İstenilmeyen değer girilmesini engelleme ve karakter sınırlama

            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
            && !char.IsSeparator(e.KeyChar);

            if (txtName.TextLength == 43)
            {
                e.Handled = true;
            }
        }

        private void txtSurname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPlcOfBirth_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtFthrName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMthrName_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSurname_KeyPress(object sender, KeyPressEventArgs e)
        {
            //İstenilmeyen değer girilmesini engelleme ve karakter sınırlama

            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
            && !char.IsSeparator(e.KeyChar);

            if (txtSurname.TextLength == 45)
            {
                e.Handled = true;
            }
        }

        private void txtPlcOfBirth_KeyPress(object sender, KeyPressEventArgs e)
        {
            //İstenilmeyen değer girilmesini engelleme ve karakter sınırlama

            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
            && !char.IsSeparator(e.KeyChar);

            if (txtPlcOfBirth.TextLength == 50)
            {
                e.Handled = true;
            }
        }

        private void txtFthrName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //İstenilmeyen değer girilmesini engelleme ve karakter sınırlama

            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
            && !char.IsSeparator(e.KeyChar);

            if (txtFthrName.TextLength == 50)
            {
                e.Handled = true;
            }
        }

        private void txtMthrName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //İstenilmeyen değer girilmesini engelleme ve karakter sınırlama

            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
            && !char.IsSeparator(e.KeyChar);

            if (txtMthrName.TextLength == 50)
            {
                e.Handled = true;
            }
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Karakter sınırlama

            if (txtPassword.TextLength == 12)
            {
                e.Handled = true;
            }
        }

        private void txtPassword_MouseHover(object sender, EventArgs e)
        {
            // Şifre girişi için bilgilendirme

            ToolTip Aciklama = new ToolTip();
            Aciklama.ToolTipTitle = "Bilgilendirme";
            Aciklama.ToolTipIcon = ToolTipIcon.Info;
            Aciklama.IsBalloon = true;

            Aciklama.SetToolTip(txtPassword, "Şifreniz en fazla 12 karakter olabilir ve özel karakterler(*,?) içermemelidir.");
        }
    }
}
