﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;

namespace HastaneOtomasyon
{
    public partial class Destek : Form
    {
        public Destek()
        {
            InitializeComponent();
        }

        private void btnGonder_Click(object sender, EventArgs e)
        {
            if (txtGonderenEposta.Text!="" && txtKonu.Text!="" && txtMesaj.Text!="")
            {
                MailMessage mesaj = new MailMessage();
                SmtpClient smtpc = new SmtpClient();
                smtpc.Credentials = new System.Net.NetworkCredential("berkantsabri5824@gmail.com","berkantfb123");
                smtpc.Port = 587;
                smtpc.Host = "smtp.gmail.com";
                smtpc.EnableSsl = true;
                mesaj.To.Add("berkantsabri5824@gmail.com");
                mesaj.From = new MailAddress(txtGonderenEposta.Text);
                mesaj.Subject = txtKonu.Text;
                mesaj.Body = txtMesaj.Text;
                smtpc.Send(mesaj);

                MessageBox.Show("Mail gönderme işleminiz gerçekleşmiştir.");

            }
            else
            {
                MessageBox.Show("Lütfen gerekli kısımları doldurun.");
            }


        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
        }

        private void txtGonderenEposta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtGonderenEposta.TextLength == 50)
            {
                e.Handled = true;
            }
        }

        private void txtKonu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtKonu.TextLength == 100)
            {
                e.Handled = true;
            }
        }

        private void txtMesaj_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtMesaj.TextLength == 255)
            {
                e.Handled = true;
            }
        }

        private void txtMesaj_TextChanged(object sender, EventArgs e)
        {
            int sayac = txtMesaj.TextLength;
            lblharfsayac.Text = sayac+"/255";
        }

        private void btnPrevious_MouseHover(object sender, EventArgs e)
        {
        }

        private void previousToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Anasayfa asf = new Anasayfa();
            this.Hide();
            asf.Show();
        }
    }
}
