﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastaneOtomasyon
{
    public partial class Duyurular : Form
    {
        public Duyurular()
        {
            InitializeComponent();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
        }

        private void previousToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Anasayfa anasf = new Anasayfa();
            this.Hide();
            anasf.Show();
        }
    }
}
