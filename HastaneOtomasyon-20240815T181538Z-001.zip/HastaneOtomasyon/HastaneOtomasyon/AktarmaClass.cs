﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HastaneOtomasyon
{
    public class AktarmaClass
    {
        public static string tc = string.Empty;
    }
}
