﻿namespace HastaneOtomasyon
{
    partial class Destek
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGonder = new System.Windows.Forms.Button();
            this.lblKonu = new System.Windows.Forms.Label();
            this.txtKonu = new System.Windows.Forms.TextBox();
            this.txtMesaj = new System.Windows.Forms.TextBox();
            this.lblMesaj = new System.Windows.Forms.Label();
            this.txtGonderenEposta = new System.Windows.Forms.TextBox();
            this.lblGonderenEposta = new System.Windows.Forms.Label();
            this.lblharfsayac = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.previousToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGonder
            // 
            this.btnGonder.BackColor = System.Drawing.Color.Transparent;
            this.btnGonder.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnGonder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGonder.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGonder.Location = new System.Drawing.Point(305, 361);
            this.btnGonder.Name = "btnGonder";
            this.btnGonder.Size = new System.Drawing.Size(125, 38);
            this.btnGonder.TabIndex = 0;
            this.btnGonder.Text = "Gönder";
            this.btnGonder.UseVisualStyleBackColor = false;
            this.btnGonder.Click += new System.EventHandler(this.btnGonder_Click);
            // 
            // lblKonu
            // 
            this.lblKonu.AutoSize = true;
            this.lblKonu.BackColor = System.Drawing.Color.Transparent;
            this.lblKonu.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKonu.Location = new System.Drawing.Point(21, 70);
            this.lblKonu.Name = "lblKonu";
            this.lblKonu.Size = new System.Drawing.Size(59, 23);
            this.lblKonu.TabIndex = 1;
            this.lblKonu.Text = "Konu :";
            // 
            // txtKonu
            // 
            this.txtKonu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtKonu.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtKonu.Location = new System.Drawing.Point(87, 70);
            this.txtKonu.Multiline = true;
            this.txtKonu.Name = "txtKonu";
            this.txtKonu.Size = new System.Drawing.Size(343, 23);
            this.txtKonu.TabIndex = 3;
            this.txtKonu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtKonu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtKonu_KeyPress);
            // 
            // txtMesaj
            // 
            this.txtMesaj.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMesaj.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtMesaj.Location = new System.Drawing.Point(87, 103);
            this.txtMesaj.Multiline = true;
            this.txtMesaj.Name = "txtMesaj";
            this.txtMesaj.Size = new System.Drawing.Size(343, 225);
            this.txtMesaj.TabIndex = 4;
            this.txtMesaj.TextChanged += new System.EventHandler(this.txtMesaj_TextChanged);
            this.txtMesaj.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMesaj_KeyPress);
            // 
            // lblMesaj
            // 
            this.lblMesaj.AutoSize = true;
            this.lblMesaj.BackColor = System.Drawing.Color.Transparent;
            this.lblMesaj.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMesaj.Location = new System.Drawing.Point(12, 99);
            this.lblMesaj.Name = "lblMesaj";
            this.lblMesaj.Size = new System.Drawing.Size(68, 23);
            this.lblMesaj.TabIndex = 5;
            this.lblMesaj.Text = "Mesaj :";
            // 
            // txtGonderenEposta
            // 
            this.txtGonderenEposta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGonderenEposta.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtGonderenEposta.Location = new System.Drawing.Point(87, 41);
            this.txtGonderenEposta.Multiline = true;
            this.txtGonderenEposta.Name = "txtGonderenEposta";
            this.txtGonderenEposta.Size = new System.Drawing.Size(343, 23);
            this.txtGonderenEposta.TabIndex = 7;
            this.txtGonderenEposta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtGonderenEposta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGonderenEposta_KeyPress);
            // 
            // lblGonderenEposta
            // 
            this.lblGonderenEposta.AutoSize = true;
            this.lblGonderenEposta.BackColor = System.Drawing.Color.Transparent;
            this.lblGonderenEposta.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGonderenEposta.Location = new System.Drawing.Point(2, 41);
            this.lblGonderenEposta.Name = "lblGonderenEposta";
            this.lblGonderenEposta.Size = new System.Drawing.Size(78, 23);
            this.lblGonderenEposta.TabIndex = 6;
            this.lblGonderenEposta.Text = "E-posta :";
            // 
            // lblharfsayac
            // 
            this.lblharfsayac.AutoSize = true;
            this.lblharfsayac.BackColor = System.Drawing.Color.Transparent;
            this.lblharfsayac.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblharfsayac.Location = new System.Drawing.Point(390, 331);
            this.lblharfsayac.Name = "lblharfsayac";
            this.lblharfsayac.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblharfsayac.Size = new System.Drawing.Size(41, 15);
            this.lblharfsayac.TabIndex = 15;
            this.lblharfsayac.Text = "0/255";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.previousToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.menuStrip1.Size = new System.Drawing.Size(442, 24);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // previousToolStripMenuItem
            // 
            this.previousToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.previousToolStripMenuItem.Image = global::HastaneOtomasyon.Properties.Resources.left_arrow;
            this.previousToolStripMenuItem.Name = "previousToolStripMenuItem";
            this.previousToolStripMenuItem.Size = new System.Drawing.Size(28, 24);
            this.previousToolStripMenuItem.Click += new System.EventHandler(this.previousToolStripMenuItem_Click);
            // 
            // Destek
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HastaneOtomasyon.Properties.Resources.RandevuWallpaper;
            this.ClientSize = new System.Drawing.Size(442, 450);
            this.ControlBox = false;
            this.Controls.Add(this.lblharfsayac);
            this.Controls.Add(this.txtGonderenEposta);
            this.Controls.Add(this.lblGonderenEposta);
            this.Controls.Add(this.lblMesaj);
            this.Controls.Add(this.txtMesaj);
            this.Controls.Add(this.txtKonu);
            this.Controls.Add(this.lblKonu);
            this.Controls.Add(this.btnGonder);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Destek";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGonder;
        private System.Windows.Forms.Label lblKonu;
        private System.Windows.Forms.TextBox txtKonu;
        private System.Windows.Forms.TextBox txtMesaj;
        private System.Windows.Forms.Label lblMesaj;
        private System.Windows.Forms.TextBox txtGonderenEposta;
        private System.Windows.Forms.Label lblGonderenEposta;
        private System.Windows.Forms.Label lblharfsayac;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem previousToolStripMenuItem;
    }
}