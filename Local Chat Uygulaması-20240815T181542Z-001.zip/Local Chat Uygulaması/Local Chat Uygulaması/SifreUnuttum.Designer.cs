﻿namespace Local_Chat_Uygulaması
{
    partial class SifreUnuttum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SifreUnuttum));
            this.bunifuGradientPanel1 = new ns1.BunifuGradientPanel();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSendCode = new System.Windows.Forms.Button();
            this.btnSifreDegistir = new ns1.BunifuThinButton2();
            this.txtDoğrulama = new ns1.BunifuMaterialTextbox();
            this.txtSifreTekrar = new ns1.BunifuMaterialTextbox();
            this.txtSifre = new ns1.BunifuMaterialTextbox();
            this.txtEposta = new ns1.BunifuMaterialTextbox();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.btnMinimize);
            this.bunifuGradientPanel1.Controls.Add(this.btnExit);
            this.bunifuGradientPanel1.Controls.Add(this.btnSendCode);
            this.bunifuGradientPanel1.Controls.Add(this.btnSifreDegistir);
            this.bunifuGradientPanel1.Controls.Add(this.txtDoğrulama);
            this.bunifuGradientPanel1.Controls.Add(this.txtSifreTekrar);
            this.bunifuGradientPanel1.Controls.Add(this.txtSifre);
            this.bunifuGradientPanel1.Controls.Add(this.txtEposta);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Violet;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.SeaGreen;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.Navy;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.SeaGreen;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(800, 450);
            this.bunifuGradientPanel1.TabIndex = 0;
            // 
            // btnMinimize
            // 
            this.btnMinimize.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimize.Image")));
            this.btnMinimize.Location = new System.Drawing.Point(728, 0);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(35, 38);
            this.btnMinimize.TabIndex = 11;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.Location = new System.Drawing.Point(765, 0);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(35, 38);
            this.btnExit.TabIndex = 10;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSendCode
            // 
            this.btnSendCode.Location = new System.Drawing.Point(442, 254);
            this.btnSendCode.Name = "btnSendCode";
            this.btnSendCode.Size = new System.Drawing.Size(139, 44);
            this.btnSendCode.TabIndex = 5;
            this.btnSendCode.Text = "Kod Gönder";
            this.btnSendCode.UseVisualStyleBackColor = true;
            this.btnSendCode.Click += new System.EventHandler(this.btnSendCode_Click);
            // 
            // btnSifreDegistir
            // 
            this.btnSifreDegistir.ActiveBorderThickness = 1;
            this.btnSifreDegistir.ActiveCornerRadius = 20;
            this.btnSifreDegistir.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSifreDegistir.ActiveForecolor = System.Drawing.Color.White;
            this.btnSifreDegistir.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSifreDegistir.BackColor = System.Drawing.SystemColors.Control;
            this.btnSifreDegistir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSifreDegistir.BackgroundImage")));
            this.btnSifreDegistir.ButtonText = "Şifreyi Değiştir";
            this.btnSifreDegistir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSifreDegistir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSifreDegistir.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSifreDegistir.IdleBorderThickness = 1;
            this.btnSifreDegistir.IdleCornerRadius = 20;
            this.btnSifreDegistir.IdleFillColor = System.Drawing.Color.White;
            this.btnSifreDegistir.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSifreDegistir.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSifreDegistir.Location = new System.Drawing.Point(278, 315);
            this.btnSifreDegistir.Margin = new System.Windows.Forms.Padding(5);
            this.btnSifreDegistir.Name = "btnSifreDegistir";
            this.btnSifreDegistir.Size = new System.Drawing.Size(238, 52);
            this.btnSifreDegistir.TabIndex = 4;
            this.btnSifreDegistir.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSifreDegistir.Click += new System.EventHandler(this.btnSifreDegistir_Click);
            // 
            // txtDoğrulama
            // 
            this.txtDoğrulama.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDoğrulama.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtDoğrulama.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDoğrulama.HintForeColor = System.Drawing.Color.Empty;
            this.txtDoğrulama.HintText = "";
            this.txtDoğrulama.isPassword = false;
            this.txtDoğrulama.LineFocusedColor = System.Drawing.Color.SeaGreen;
            this.txtDoğrulama.LineIdleColor = System.Drawing.Color.Gray;
            this.txtDoğrulama.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtDoğrulama.LineThickness = 3;
            this.txtDoğrulama.Location = new System.Drawing.Point(211, 254);
            this.txtDoğrulama.Margin = new System.Windows.Forms.Padding(4);
            this.txtDoğrulama.Name = "txtDoğrulama";
            this.txtDoğrulama.Size = new System.Drawing.Size(224, 44);
            this.txtDoğrulama.TabIndex = 3;
            this.txtDoğrulama.Text = "Doğrulama Kodu";
            this.txtDoğrulama.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSifreTekrar
            // 
            this.txtSifreTekrar.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSifreTekrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSifreTekrar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSifreTekrar.HintForeColor = System.Drawing.Color.Empty;
            this.txtSifreTekrar.HintText = "";
            this.txtSifreTekrar.isPassword = false;
            this.txtSifreTekrar.LineFocusedColor = System.Drawing.Color.SeaGreen;
            this.txtSifreTekrar.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSifreTekrar.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSifreTekrar.LineThickness = 3;
            this.txtSifreTekrar.Location = new System.Drawing.Point(211, 193);
            this.txtSifreTekrar.Margin = new System.Windows.Forms.Padding(4);
            this.txtSifreTekrar.Name = "txtSifreTekrar";
            this.txtSifreTekrar.Size = new System.Drawing.Size(370, 44);
            this.txtSifreTekrar.TabIndex = 2;
            this.txtSifreTekrar.Text = "Yeni Şifre Tekrar";
            this.txtSifreTekrar.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSifre
            // 
            this.txtSifre.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtSifre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSifre.HintForeColor = System.Drawing.Color.Empty;
            this.txtSifre.HintText = "";
            this.txtSifre.isPassword = false;
            this.txtSifre.LineFocusedColor = System.Drawing.Color.SeaGreen;
            this.txtSifre.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSifre.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSifre.LineThickness = 3;
            this.txtSifre.Location = new System.Drawing.Point(211, 131);
            this.txtSifre.Margin = new System.Windows.Forms.Padding(4);
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.Size = new System.Drawing.Size(370, 44);
            this.txtSifre.TabIndex = 1;
            this.txtSifre.Text = "Yeni Şifre";
            this.txtSifre.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtEposta
            // 
            this.txtEposta.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEposta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtEposta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtEposta.HintForeColor = System.Drawing.Color.Empty;
            this.txtEposta.HintText = "";
            this.txtEposta.isPassword = false;
            this.txtEposta.LineFocusedColor = System.Drawing.Color.SeaGreen;
            this.txtEposta.LineIdleColor = System.Drawing.Color.Gray;
            this.txtEposta.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtEposta.LineThickness = 3;
            this.txtEposta.Location = new System.Drawing.Point(211, 68);
            this.txtEposta.Margin = new System.Windows.Forms.Padding(4);
            this.txtEposta.Name = "txtEposta";
            this.txtEposta.Size = new System.Drawing.Size(370, 44);
            this.txtEposta.TabIndex = 0;
            this.txtEposta.Text = "E-posta";
            this.txtEposta.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtEposta.Validating += new System.ComponentModel.CancelEventHandler(this.txtEposta_Validating);
            // 
            // SifreUnuttum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SifreUnuttum";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SifreUnuttum";
            this.Load += new System.EventHandler(this.SifreUnuttum_Load);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ns1.BunifuGradientPanel bunifuGradientPanel1;
        private ns1.BunifuMaterialTextbox txtSifreTekrar;
        private ns1.BunifuMaterialTextbox txtSifre;
        private ns1.BunifuMaterialTextbox txtEposta;
        private ns1.BunifuThinButton2 btnSifreDegistir;
        private ns1.BunifuMaterialTextbox txtDoğrulama;
        private System.Windows.Forms.Button btnSendCode;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnExit;
    }
}