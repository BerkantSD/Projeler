﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace Local_Chat_Uygulaması
{
    public partial class SifreUnuttum : Form
    {
        public SifreUnuttum()
        {
            InitializeComponent();
        }

        private void SifreUnuttum_Load(object sender, EventArgs e)
        {
            btnSifreDegistir.BackColor = Color.Transparent;
        }

        private void btnSifreDegistir_Click(object sender, EventArgs e)
        {
            if (txtEposta.Text!="" & txtSifre.Text!="" & txtSifreTekrar.Text!="" & txtDoğrulama.Text!="")
            {
                if (txtEposta.Text.Length <= 70 & txtSifre.Text.Length <= 12 & txtSifreTekrar.Text.Length <= 12)
                {
                    if (code == txtDoğrulama.Text)
                    {
                        KayitOl ko = new KayitOl();
                        ko.epostasi = txtEposta.Text;
                        ko.sifresi = txtSifre.Text;
                        ko.guncelle();
                        MessageBox.Show("Şifreniz güncellenmiştir. Ana sayfaya yönlendiriliyorsunuz...");
                        Giris grs = new Giris();
                        this.Hide();
                        grs.Show();
                    }
                    else
                    {
                        MessageBox.Show("Doğrulama kodu yanlış, lütfen kodu doğru yazdığınızdan emin olunuz!");
                    }
                }
                else if (txtEposta.Text.Length > 70)
                    MessageBox.Show("E-posta adresiniz 70 karakterden fazla olamaz!");
                else if (txtSifre.Text.Length > 12)
                    MessageBox.Show("Şifreniz 12 karakterden fazla olamaz!");
                else if (txtSifreTekrar.Text.Length > 12)
                    MessageBox.Show("Şifreniz 12 karakterden fazla olamaz!");
            }
            else
            {
                MessageBox.Show("Lütfen bilgilerinizi ve doğrulama kodunu giriniz!");
            }
        }
        string code;
        private void btnSendCode_Click(object sender, EventArgs e)
        {
            try
            {
                ConfirmCode cc = new ConfirmCode();
                SmtpClient client = new SmtpClient();
                MailMessage mesaj = new MailMessage();
                client.Credentials = new System.Net.NetworkCredential("aydind910@gmail.com", "hltcNfb1234");
                client.Port = 587;
                client.Host = "smtp.gmail.com";
                client.EnableSsl = true;
                mesaj.To.Add(txtEposta.Text);
                mesaj.From = new MailAddress("aydind910@gmail.com");
                mesaj.Subject = "Hansa Chat Confirm Code";
                code=cc.rastgele();
                mesaj.Body = code;
                client.Send(mesaj);
                MessageBox.Show("Doğrulama kodu mail hesabınıza gönderildi!");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Mail hesabınız düşük güvenlikli uygulamara açık olmalıdır! İzin vermek için https://myaccount.google.com/u/1/lesssecureapps sitesini ziyaret ediniz. \n \n"+ ex.Message);
            }
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Giris grs = new Giris();
            this.Hide();
            grs.Show();
        }

        private void txtEposta_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
            if (txtEposta.Text.Length > 0)
            {
                if (!rEMail.IsMatch(txtEposta.Text))
                {
                    MessageBox.Show("E-Mail expected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    e.Cancel = true;
                }
            }
        }
    }
}
